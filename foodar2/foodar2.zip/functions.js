function myFunction(zipcode) {

    var reply 
    if(zipcode > 20000) {
        console.log("you enter a correct zipcode");
    } else {
        console.log("you have entered an incorrect zipcode");
    }
    
  }